Desarrolla en C++ dentro VS2022 los siguientes ejercicios (usando clases en modo manual): 
Confeccionar una clase que administre una lista tipo pila (se debe poder insertar, extraer e imprimir los datos de la pila)
Agregar a la clase Pila un método que retorne la cantidad de nodos y otro que indique si esta vacía.
Agregar un método a la clase Pila que retorne la información del primer nodo de la Pila sin borrarlo.
Se debe desarrollar una clase que tenga las siguientes responsabilidades (clase Formula):
Ingresar una fórmula que contenga paréntesis, corchetes y llaves.
Validar que los ( ) [] y {} estén correctamente balanceados.
