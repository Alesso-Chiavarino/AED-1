#include <iostream>
#include <stack>

using namespace std;

