while (current != nullptr) {
		// 	cout <<"Elemento:"<< current->num << " " << endl;
		// 	res = current->num - res;
		// 	current = current->next;
		// }