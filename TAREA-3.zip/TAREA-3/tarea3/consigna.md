Desarrollar un programa que sea capaz de almacenar los datos de 50 personas: nombre, dirección, teléfono, edad (usando una tabla de structs). Deberá ir pidiendo los datos uno por uno, hasta que un nombre se introduzca vacío (se pulse Intro sin teclear nada). Entonces deberá aparecer un menú que permita:

· Mostrar la lista de todos los nombres.

· Mostrar las personas de una cierta edad.

· Mostrar las personas cuya inicial sea la que el usuario indique.

· Salir del programa (lógicamente, este menú debe repetirse hasta que se escoja la opción de “salir”).