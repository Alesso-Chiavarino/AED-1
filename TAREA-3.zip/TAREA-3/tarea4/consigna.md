1. Mejorar la base de datos de ficheros (enunciado 1) para que no permita introducir tamaños incorrectos (números negativos) ni nombres de fichero vacíos.

2. Ampliar la base de datos de ficheros (enunciado 1) para que incluya una opción de búsqueda parcial, en la que el usuario indique parte del nombre y se muestre todos los ficheros que contienen ese fragmento.

3. Ampliar la base de datos de ficheros (enunciado 1) para que se pueda borrar un cierto dato (habrá que “mover hacia atrás” todos los datos que había después de ese, y disminuir el contador de la cantidad de datos que tenemos).

4. Mejorar la base de datos de ficheros (enunciado 1) para que se pueda modificar un cierto dato a partir de su número (por ejemplo, el dato número 3). En esa modificación, se deberá permitir al usuario pulsar Intro sin teclear nada, para indicar que no desea modificar un cierto dato, en vez de reemplazarlo por una cadena vacía.

5. Ampliar la base de datos de ficheros (enunciado 1) para que se permita ordenar los datos por nombre. Para ello, deberás buscar información sobre algún método de ordenación sencillo, como el "método de burbuja" (en el siguiente apartado tienes algunos), y aplicarlo a este caso concreto.