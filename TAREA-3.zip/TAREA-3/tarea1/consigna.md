Desarrollar un programa que pueda almacenar datos de hasta 1000 ficheros (archivos de ordenador). Para cada fichero, debe guardar los siguientes datos: Nombre del fichero (max 40 letras), Tamaño (en KB, número de 0 a 2.000.000.000). El programa mostrará un menú que permita al usuario las siguientes operaciones:

1- Añadir datos de un nuevo fichero

2- Mostrar los nombres de todos los ficheros almacenados

3- Mostrar ficheros que sean de más de un cierto tamaño (por ejemplo, 2000 KB).

4- Ver todos los datos de un cierto fichero (a partir de su nombre)

5- Salir de la aplicación (como todavía no sabemos almacenar los datos, éstos se perderán).
